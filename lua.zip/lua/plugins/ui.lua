return {
  { "nvim-lualine/lualine.nvim" },
  { "folke/trouble.nvim", dependencies = { "nvim-tree/nvim-web-devicons" } },
  config = function()
    local ok, lualine = pcall(require, "lualine")
    if ok then lualine.setup() end

    local ok2, trouble = pcall(require, "trouble")
    if ok2 then
      trouble.setup()
      vim.keymap.set("n","<leader>xx", "<cmd>TroubleToggle<CR>")
    end
  end
}