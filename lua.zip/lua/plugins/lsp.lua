return {
  { "neovim/nvim-lspconfig" },
  { "williamboman/mason.nvim" },
  { "williamboman/mason-lspconfig.nvim" },
  { "onsails/lspkind.nvim" },
  { "nvim-treesitter/nvim-treesitter", build = ":TSUpdate" },

  config = function()
    local lspconfig = require("lspconfig")
    local mason = require("mason")
    local mason_lsp = require("mason-lspconfig")
    local capabilities = require("cmp_nvim_lsp").default_capabilities()

    mason.setup()
    mason_lsp.setup({ ensure_installed = { "pyright","ts_ls","html","cssls","jsonls","clangd" } })
    mason_lsp.setup_handlers({ function(server_name)
      lspconfig[server_name].setup({ capabilities = capabilities })
    end })

    vim.api.nvim_create_autocmd("LspAttach", {
      callback = function(ev)
        local opts = { buffer = ev.buf }
        vim.keymap.set("n","gd", vim.lsp.buf.definition, opts)
        vim.keymap.set("n","K", vim.lsp.buf.hover, opts)
        vim.keymap.set("n","gr", vim.lsp.buf.references, opts)
        vim.keymap.set("n","<leader>rn", vim.lsp.buf.rename, opts)
        vim.keymap.set("n","<leader>ca", vim.lsp.buf.code_action, opts)
        vim.keymap.set("n","<leader>ff", function() vim.lsp.buf.format({ async=true }) end, opts)
      end
    })

    vim.diagnostic.config({
      virtual_text = { prefix = "●" },
      signs = true,
      underline = true,
      update_in_insert = false,
      severity_sort = true,
      float = { border = "rounded" },
    })

    vim.fn.sign_define("DiagnosticSignError", { text = "", texthl = "DiagnosticSignError" })
    vim.fn.sign_define("DiagnosticSignWarn",  { text = "", texthl = "DiagnosticSignWarn" })
    vim.fn.sign_define("DiagnosticSignInfo",  { text = "", texthl = "DiagnosticSignInfo" })
    vim.fn.sign_define("DiagnosticSignHint",  { text = "󰌵", texthl = "DiagnosticSignHint" })
  end
}