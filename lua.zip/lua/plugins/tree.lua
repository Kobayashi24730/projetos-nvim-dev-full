return {
  { "nvim-tree/nvim-tree.lua", dependencies = { "nvim-tree/nvim-web-devicons" } },
  config = function()
    local ok, tree = pcall(require, "nvim-tree")
    if ok then
      tree.setup()
      vim.keymap.set("n","<leader>e",":NvimTreeToggle<CR>")
    end
  end
}