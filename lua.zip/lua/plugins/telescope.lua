return {
  { "nvim-telescope/telescope.nvim", dependencies = { "nvim-lua/plenary.nvim" } },
  { "nvim-telescope/telescope-fzf-native.nvim", build = "make" },
  config = function()
    local ok, tb = pcall(require, "telescope.builtin")
    if ok then
      vim.keymap.set("n","<leader>f", tb.find_files)
      vim.keymap.set("n","<leader>g", tb.live_grep)
    end
  end
}