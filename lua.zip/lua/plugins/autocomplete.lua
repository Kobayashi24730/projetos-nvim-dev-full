return {
  { "hrsh7th/nvim-cmp" },
  { "hrsh7th/cmp-nvim-lsp" },
  { "hrsh7th/cmp-buffer" },
  { "hrsh7th/cmp-path" },
  { "L3MON4D3/LuaSnip" },
  { "saadparwaiz1/cmp_luasnip" },
  { "windwp/nvim-autopairs", event = "InsertEnter" },
  { "stevearc/conform.nvim" },

  config = function()
    local cmp = require("cmp")
    local luasnip = require("luasnip")
    local cmp_autopairs = require("nvim-autopairs.completion.cmp")
    cmp.event:on("confirm_done", cmp_autopairs.on_confirm_done())

    cmp.setup({
      snippet = { expand = function(args) luasnip.lsp_expand(args.body) end },
      mapping = cmp.mapping.preset.insert({
        ["<Tab>"] = cmp.mapping.select_next_item(),
        ["<S-Tab>"] = cmp.mapping.select_prev_item(),
        ["<CR>"] = cmp.mapping.confirm({ select = true }),
        ["<C-Space>"] = cmp.mapping.complete(),
      }),
      sources = { { name = "nvim_lsp" }, { name = "buffer" }, { name = "path" } },
      formatting = { format = require("lspkind").cmp_format({ mode="symbol_text", maxwidth=50 }) },
    })

    vim.keymap.set({"n","v"}, "<leader>fm", function()
      require("conform").format({ async = true, lsp_fallback = true })
    end)
  end
}